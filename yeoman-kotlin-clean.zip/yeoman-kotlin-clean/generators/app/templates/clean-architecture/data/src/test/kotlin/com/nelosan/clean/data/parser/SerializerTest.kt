package <%= appPackage %>.data.check

/**
 * Created by nelo on 21/3/17.
 */
class SerializerTest {

}