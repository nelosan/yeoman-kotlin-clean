package <%= appPackage %>.presentation.navigation

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by nelo on 21/2/17.
 */
@Singleton
class Navigator @Inject constructor(){

}