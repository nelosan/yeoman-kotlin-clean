package <%= appPackage %>.presentation.view.view

/**
 * Created by nelo on 8/3/17.
 */
interface BaseView