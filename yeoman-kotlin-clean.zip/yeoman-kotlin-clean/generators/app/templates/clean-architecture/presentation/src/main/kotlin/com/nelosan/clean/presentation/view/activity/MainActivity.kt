package <%= appPackage %>.presentation.view.activity

/**
 * Created by nelo on 4/5/17.
 */
class MainActivity: BaseActivity() {
}